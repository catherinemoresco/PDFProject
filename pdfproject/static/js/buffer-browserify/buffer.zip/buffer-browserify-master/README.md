buffer-browserify
===============

The buffer module from [node.js](http://nodejs.org/),
but for browsers.

When you `require('buffer')` in
[browserify](http://github.com/substack/node-browserify),
this module will be loaded.

It will also be loaded if you use the global `Buffer` variable.
